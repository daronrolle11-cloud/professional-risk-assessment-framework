import type { AssessmentForm, HazardDraft, HazardTemplate } from "@/lib/types";

export interface StepProps {
  form: AssessmentForm;
  patch: (p: Partial<AssessmentForm>) => void;
  addFromTemplate: (t: HazardTemplate) => void;
  addCustom: () => void;
  removeHazard: (uid: string) => void;
  updateHazard: (uid: string, p: Partial<HazardDraft>) => void;
}

export function StepHeader({ kicker, title, desc }: { kicker: string; title: string; desc?: string }) {
  return (
    <div className="mb-7">
      <div className="mono-label mb-2">{kicker}</div>
      <h2 className="font-display text-2xl md:text-3xl">{title}</h2>
      {desc && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-white/50">{desc}</p>}
    </div>
  );
}

export function Label({ children, hint }: { children: React.ReactNode; hint?: string }) {
  return (
    <label className="mb-1.5 block">
      <span className="mono-label !text-[9.5px]">{children}</span>
      {hint && <span className="mono mt-0.5 block text-[9px] normal-case tracking-normal text-white/30">{hint}</span>}
    </label>
  );
}

export function Chip({ children, tone = "default" }: { children: React.ReactNode; tone?: "default" | "amber" }) {
  return (
    <span
      className={`mono inline-flex items-center rounded border px-2 py-1 text-[9px] uppercase tracking-[0.14em] ${
        tone === "amber" ? "border-[var(--brand-teal)]/50 bg-[var(--brand-teal)]/10 text-[var(--brand-teal-soft)]" : "border-white/12 bg-white/[0.04] text-white/45"
      }`}
    >
      {children}
    </span>
  );
}
