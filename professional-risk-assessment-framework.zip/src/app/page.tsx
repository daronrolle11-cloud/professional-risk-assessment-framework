import { LandingNav, LandingFooter } from "@/components/landing-nav";
import { LandingHero } from "@/components/landing-hero";
import { LandingMethod } from "@/components/landing-method";
import { LandingMatrix } from "@/components/landing-matrix";
import { LandingSuite } from "@/components/landing-suite";

export default function Home() {
  return (
    <main className="min-h-screen">
      <LandingNav />
      <LandingHero />
      <LandingMethod />
      <LandingMatrix />
      <LandingSuite />
      <LandingFooter />
    </main>
  );
}
