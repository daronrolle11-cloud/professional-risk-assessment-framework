/**
 * Database client — compatible with both local PostgreSQL and Neon serverless.
 *
 * • In development (or any env where NEON_DATABASE_URL is NOT set):
 *   Uses the standard `pg` Pool against DATABASE_URL.
 *
 * • In production on Netlify (or Neon):
 *   Uses @neondatabase/serverless so each Netlify Function invocation
 *   gets a fresh connection that closes cleanly without leaking sockets.
 *   Set NEON_DATABASE_URL to your Neon pooled connection string.
 *
 * Drizzle ORM provides identical API over both adapters.
 */

import { drizzle as drizzleNeon } from "drizzle-orm/neon-serverless";
import { drizzle as drizzlePg } from "drizzle-orm/node-postgres";
import { Pool as NeonPool } from "@neondatabase/serverless";
import { Pool as PgPool } from "pg";

const neonUrl = process.env.NEON_DATABASE_URL;
const pgUrl = process.env.DATABASE_URL;

if (!neonUrl && !pgUrl) {
  throw new Error(
    "A database URL is required. Set NEON_DATABASE_URL (production/Netlify) or DATABASE_URL (local development)."
  );
}

// Use Neon driver when NEON_DATABASE_URL is present (Netlify / cloud)
// Fall back to standard pg Pool for local development
const globalForDb = globalThis as typeof globalThis & {
  __bcso_db_pool?: NeonPool | PgPool;
};

function makePool() {
  if (neonUrl) {
    return new NeonPool({ connectionString: neonUrl });
  }
  return new PgPool({ connectionString: pgUrl! });
}

export const pool: NeonPool | PgPool =
  globalForDb.__bcso_db_pool ?? makePool();

if (process.env.NODE_ENV !== "production") {
  globalForDb.__bcso_db_pool = pool;
}

// Export a unified `db` — Drizzle's API is identical for both drivers
export const db = neonUrl
  ? drizzleNeon(pool as NeonPool)
  : drizzlePg(pool as PgPool);
