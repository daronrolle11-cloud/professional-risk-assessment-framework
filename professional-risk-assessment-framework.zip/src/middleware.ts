import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// Auth is handled entirely client-side via localStorage + x-bcso headers.
// This middleware does nothing — it just passes every request straight through.
export function middleware(_request: NextRequest) {
  return NextResponse.next();
}

export const config = {
  matcher: [],
};
